package com.apassignment2.socialnetwork;

import com.apassignment2.socialnetwork.gui.MainFrame;

/**
 * 
 * main startup class
 *
 */
public class MiniNet {

	public MiniNet() {

	}

	public static void main(String[] args) {
		
		
		new MainFrame();

	}

}
