package com.apassignment2.socialnetwork.database;

import com.apassignment2.socialnetwork.model.Adult;
import com.apassignment2.socialnetwork.model.Child;
import com.apassignment2.socialnetwork.model.Kid;
import com.apassignment2.socialnetwork.model.Person;
import com.apassignment2.socialnetwork.model.interfaces.AdultClassmate;
import com.apassignment2.socialnetwork.model.interfaces.AdultFriend;
import com.apassignment2.socialnetwork.model.interfaces.ChildClassmate;
import com.apassignment2.socialnetwork.model.interfaces.ChildFriend;
import com.apassignment2.socialnetwork.model.interfaces.Colleague;
import com.apassignment2.socialnetwork.model.interfaces.Partner;

public class DBHelper {
	
	private Database db = Database.getInstance();
	
	private static  DBHelper instance;
	
	private Callback callback = null;
	
	private DBHelper(){
		
	}
	public static DBHelper getInstance(){
		if(instance == null){
			instance = new DBHelper();
		}
		return instance;
	}
	
	public Object[][] getAllPersonInformationArray(){
		

		
		Object[][]  data = new Object[db.personList.size()][10];
		
		for(int i = 0 ; i < db.personList.size() ; i ++){
			Person person = db.personList.get(i);
			data[i] = person.generateInfoDataArray();
		}
		
		return data;
	}
	
	public void addNewPerson(String name,String status,String gender, int age ,String state){
			
		db.addNewPerson(name, status, gender, age, state);
		this.notifyDataChanged();
		
	}
	
	public interface Callback{
		
		public void onChanged();
		
	}
	
	public void setCallback(Callback cb){
		this.callback = cb;
	}
	
	public Person getPersonByIndex(int i ){
		return db.personList.get(i);
	}
	
	public void disConnectFromFriendList(AdultFriend friend1,AdultFriend friend2){
		
		friend1.removeFriend(friend2);
		friend2.removeFriend(friend1);
		this.notifyDataChanged();
	}
	
	public void disConnectFromFriendList(ChildFriend friend1,ChildFriend friend2){
		
		friend1.removeFriend(friend2);
		friend2.removeFriend(friend1);
		this.notifyDataChanged();
	}
	
	public void disConnectFromClassmateList(AdultClassmate classmate1,AdultClassmate classmate2){
		
		classmate1.removeClassmate(classmate2);
		classmate2.removeClassmate(classmate1);
		this.notifyDataChanged();
	}
	
	public void disConnectFromClassmateList(ChildClassmate classmate1,ChildClassmate classmate2){
		
		classmate1.removeClassmate(classmate2);
		classmate2.removeClassmate(classmate1);
		this.notifyDataChanged();
	}
	
	public void disConnectFromColleagueList(Colleague colleague1,Colleague colleague2){
		
		colleague1.removeColleague(colleague2);
		colleague2.removeColleague(colleague1);
		this.notifyDataChanged();
	}
	
	public void removePerson(Person person){
		
		if(person instanceof Adult){
			Adult adult = (Adult)person;
			Partner partner = adult.getPartner();
			if(partner != null){//if has partner
				for(Kid kid : adult.getKids()){
					kid.setFather(null);
					kid.setMother(null);
				}
				partner.getKids().clear();
				adult.getKids().clear();
				partner.marryWith(null);
				adult.marryWith(null);
			}
			//clear friends
			for(AdultFriend friend : adult.getFriends()){
				friend.getFriends().remove(adult);
			}
			adult.getFriends().clear();
			//clear colleagues
			for(Colleague colleague : adult.getColleagues()){
				colleague.getColleagues().remove(adult);
			}
			adult.getColleagues().clear();
			//clear classmates
			for(AdultClassmate classmate : adult.getClassmates()){
				classmate.getClassmates().remove(adult);
			}
			adult.getClassmates().clear();
		}else{
			
			Kid kid = (Kid)person;
			Partner father = kid.getFather();
			father.removeKid(kid);
			Partner mother = kid.getMother();
			mother.removeKid(kid);
			kid.setFather(null);
			kid.setMother(null);
			if(kid instanceof Child){
				Child child = (Child) kid;
				//clear friends
				for(ChildFriend friend : child.getFriends()){
					friend.getFriends().remove(child);
				}
				child.getClassmates().clear();
				//clear classmates
				for(ChildClassmate colleague : child.getClassmates()){
					colleague.getClassmates().remove(child);
				}
				child.getClassmates().clear();
			}
			
		} 
		this.db.personList.remove(person);
		this.notifyDataChanged();
	}
	

	
	
	public void notifyDataChanged(){
		if(this.callback != null){
			this.callback.onChanged();
		}
	}

}
