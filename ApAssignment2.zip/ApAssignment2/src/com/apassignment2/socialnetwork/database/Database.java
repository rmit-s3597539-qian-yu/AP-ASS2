package com.apassignment2.socialnetwork.database;



import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.apassignment2.socialnetwork.model.Adult;
import com.apassignment2.socialnetwork.model.Child;
import com.apassignment2.socialnetwork.model.Kid;
import com.apassignment2.socialnetwork.model.Person;
import com.apassignment2.socialnetwork.model.YoungChild;

public class Database {

	protected static final String PPL_FILE_NAME = "people.txt";
	protected static final  String REL_FILE_NAME = "relations.txt";

	private static Database instance;
	protected ArrayList<Person> personList = new ArrayList<Person>(); // all users
																


	protected static Database getInstance() {
		if (instance == null) {
			instance = new Database();
		}
		return instance;
	}
	private Database() {
		init();
	}
	
	/**
	 * initialize data when startup.
	 */
	private void init() {
		
		try {
			/*
			 * 1. load data from people.txt file
			 */

			FileReader pplFileReader = new FileReader(PPL_FILE_NAME);
			BufferedReader pplFileBReader = new BufferedReader(pplFileReader);

			String pplStr = null;
			String ppl[] = null;
			while ((pplStr = pplFileBReader.readLine()) != null) {
				ppl = pplStr.split(", ");

				String name = ppl[0];
				String photoPath = ppl[1];
				String status = ppl[2];
				String gender = ppl[3];
				Integer age = Integer.parseInt(ppl[4].trim());
				String state = ppl[5];

				this.addNewPerson(name, status, gender, age, state);
			

			}
			pplFileBReader.close();
			pplFileReader.close();
			
			/*
			 * 2. load data from relations.txt file
			 */
			FileReader relFileReader = new FileReader(REL_FILE_NAME);
			BufferedReader relBReader = new BufferedReader(relFileReader);

			String relStr = null;
			String rel[] = null;
			while ((relStr = relBReader.readLine()) != null) {
				rel = relStr.split(", ");
				String frist = rel[0];
				String second = rel[1];
				String relation = rel[2].toLowerCase().trim();

				makeConnection(frist,second,relation);
	

			}

			relBReader.close();
			relFileReader.close();
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	

	}
	
	private void makeConnection(String first,String second,String relation){
		
		if (relation.equals("friends")) {
			makeConnectionAsFriends(first, second);
		} else if (relation.equals("couple")) {
			makeConnectionAsCouples(first, second);
		} else if (relation.equals("parent")) {
			makeConnectionAsParent(first, second);
		} else if (relation.equals("colleagues")){
			makeConnectionAsColleagues(first, second);
		} else if (relation.equals("classmates")){
			makeConnectionAsClassMates(first, second);
		}
	}
	
	private void makeConnectionAsFriends(String first,String second){
		
		Person fP = getPersonByName(first);
		Person sP = getPersonByName(second);
		
		if(fP != null && sP != null){
			if(fP instanceof Adult && sP instanceof Adult){
				
				Adult fA = (Adult)fP;
				Adult sA = (Adult)sP;
				fA.addFriend(sA);
				sA.addFriend(fA);
				
			}else if(fP instanceof Child && sP instanceof Child){
				
				Child fC = (Child)fP;
				Child sC = (Child)sP;
				fC.addFriend(sC);
				sC.addFriend(fC);
				
			}
		}
	}
	
	private void makeConnectionAsCouples(String first,String second){
		
		Person fP = getPersonByName(first);
		Person sP = getPersonByName(second);
		
		if(fP != null && sP != null){
			if(fP instanceof Adult && sP instanceof Adult){
				
				Adult fA = (Adult)fP;
				Adult sA = (Adult)sP;
				fA.marryWith(sA);
				sA.marryWith(fA);
				
			}
		}
	}
	
	private void makeConnectionAsParent(String first,String second){
		
		Person fP = getPersonByName(first);
		Person sP = getPersonByName(second);
		
		if(fP != null && sP != null){
			if(fP instanceof Adult && sP instanceof Kid){
				
				Adult adult = (Adult)fP;
				Kid kid = (Kid)sP;
				
				adult.addKid(kid);
				kid.setParent(adult);
				
			}else if(sP instanceof Adult && fP instanceof Kid){
			
				Adult adult = (Adult)sP;
				Kid kid = (Kid)fP;
				
				adult.addKid(kid);
				kid.setParent(adult);
			}
		}
		
	}
	
	private void makeConnectionAsColleagues(String first,String second){
		
		Person fP = getPersonByName(first);
		Person sP = getPersonByName(second);
		
		if(fP != null && sP != null){
			if(fP instanceof Adult && sP instanceof Adult){
				
				Adult fA = (Adult)fP;
				Adult sA = (Adult)sP;
				fA.addColleague(sA);
				sA.addColleague(fA);
				
			}
		}
	}
	
	private void makeConnectionAsClassMates(String first,String second){
		
		Person fP = getPersonByName(first);
		Person sP = getPersonByName(second);
		
		if(fP != null && sP != null){
			if(fP instanceof Adult && sP instanceof Adult){
				
				Adult fA = (Adult)fP;
				Adult sA = (Adult)sP;
				fA.addClassmate(sA);
				sA.addClassmate(fA);
				
			}else if(fP instanceof Child && sP instanceof Child){
				
				Child fC = (Child)fP;
				Child sC = (Child)sP;
				fC.addClassmate(sC);
				sC.addClassmate(fC);
				
			}
		}
	}
	
	private Person getPersonByName(String name){
		Person found = null;
		
		for(Person person : personList){
			if(person.getName().equals(name)){
				found = person;
				break;
			}
		}
		
		return found;
	}
	
	protected void addNewPerson(String name,String status,String gender, int age ,String state){
		
		this.addNewPerson(name, Person.DEFAULT_EMPTY_PHOTO_PATH, status, gender, age, state);
	}
	
	protected void addNewPerson(String name,String photoPath,String status,String gender, int age ,String state){

		
		if (age > 16) {
			Adult adult = new Adult(name, photoPath, status, gender, age, state);
			this.personList.add(adult);
		} else if (age <= 16 && age >= 3) {
			Child teen = new Child(name, photoPath, status, gender, age, state);
			this.personList.add(teen);
		} else {
			YoungChild teen = new YoungChild(name, photoPath, status, gender, age, state);
			this.personList.add(teen);
		}
	}

}
