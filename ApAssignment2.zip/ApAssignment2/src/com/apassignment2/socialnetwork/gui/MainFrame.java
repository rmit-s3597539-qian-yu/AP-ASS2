package com.apassignment2.socialnetwork.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import com.apassignment2.socialnetwork.Helper;
import com.apassignment2.socialnetwork.database.DBHelper;
import com.apassignment2.socialnetwork.exceptions.NoSelectException;
import com.apassignment2.socialnetwork.exceptions.SelectLessThanTwoException;
import com.apassignment2.socialnetwork.exceptions.SelectMoreThanOneException;
import com.apassignment2.socialnetwork.exceptions.SelectMoreThanTwoException;
import com.apassignment2.socialnetwork.exceptions.SelectSamePersonException;
import com.apassignment2.socialnetwork.exceptions.SocialNetworkException;
import com.apassignment2.socialnetwork.exceptions.TooYoungException;
import com.apassignment2.socialnetwork.model.Adult;
import com.apassignment2.socialnetwork.model.Child;
import com.apassignment2.socialnetwork.model.Kid;
import com.apassignment2.socialnetwork.model.Person;
import com.apassignment2.socialnetwork.model.YoungChild;
import com.apassignment2.socialnetwork.model.interfaces.AdultClassmate;
import com.apassignment2.socialnetwork.model.interfaces.AdultFriend;
import com.apassignment2.socialnetwork.model.interfaces.ChildClassmate;
import com.apassignment2.socialnetwork.model.interfaces.ChildFriend;
import com.apassignment2.socialnetwork.model.interfaces.Colleague;

public class MainFrame extends SocialNetworkJFrame implements DBHelper.Callback
{  
	
	/* JTable components Area */
	
	private JTable table = null; 
	
	/* JPopupMenu components Area */
	private JMenuBar menuBar;
	
	private JMenu infoMenu;
	//infoMenu Options
	private JMenuItem addNewItem;
	private JMenuItem displayProfileItem;
	private JMenuItem removeItem;
	
	
	private JMenu relationMenu;
	//relationMenu Options:
	private JMenuItem findOutRelationShipItem;
	private JMenuItem makeConnectionItem;
	private JMenuItem friendsItem;
	private JMenuItem colleaguesItem;
	private JMenuItem classmatesItem;
	private MultipleSelectedTableModel msTableModel;
//	public int selectedCount = 0;
//	public boolean[] selectedStates;
	
  
    public MainFrame()  
    {  
   	 	super("Main Frame");
        initUI();  
    }  
  
    /** 
     * initialize UI components
     */  
    protected void initUI()  
    {  
    	DBHelper.getInstance().setCallback(this);
    	initMenu();
    	initFrame();
    }  
    
    private void initMenu(){

	      /******************* infoMenu initialization area  *******************/
	      infoMenu = new JMenu("Information Menu");// menu
	      //1. add new item
	      addNewItem = new JMenuItem("Add New Person");
	      addNewItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddNewPersonFrame();
			}
	    	  
	      });
	      infoMenu.add(addNewItem);
	      //2. edit profile ite
	      displayProfileItem = new JMenuItem("Display Profile");
	      displayProfileItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(selectedCount < 1){
						throw new NoSelectException("No person is selected.");
					}else if(selectedCount > 1){
						throw new SelectMoreThanOneException("Only one person's profile can be shown at same time.");
					}
					Person selectedPerson = DBHelper.getInstance().getPersonByIndex(msTableModel.getSelectedRowIndexs()[0]);
					new DisplayProfileFrame(selectedPerson);
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
				
			}
	    	  
	      });
	      infoMenu.add(displayProfileItem);

	      //4. remove person from system item
	      removeItem = new JMenuItem("Remove From System");
	      removeItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(selectedCount < 1){
						throw new NoSelectException("No person is selected.");
					}else if(selectedCount > 1){
						throw new SelectMoreThanOneException("Only one person can be deleted at same time.");
					}
					Person selectedPerson = DBHelper.getInstance().getPersonByIndex(msTableModel.getSelectedRowIndexs()[0]);
					DBHelper.getInstance().removePerson(selectedPerson);
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
		
			}
	    	  
	      });
	      infoMenu.add(removeItem);
	      
	      
	      /******************* relationMenu initialization area  *******************/
	      relationMenu = new JMenu("Relation Menu");// menu
	      //1. check relationship for the two selected persons
	      findOutRelationShipItem = new JMenuItem("Find out Relationship");
	      findOutRelationShipItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
 
				
				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(msTableModel.getSelectedRowCount() < 2){
						throw new SelectLessThanTwoException("Selected person count is less than two! Only two selected persons are allowed.");
					}else if(selectedCount > 2){
						throw new SelectMoreThanTwoException("Selected person count is more than two! Only two selected persons are allowed.");
					}
					int[] selectedIndexs =  msTableModel.getSelectedRowIndexs();
					Person selectedPerson1 = DBHelper.getInstance().getPersonByIndex(selectedIndexs[0]);
					Person selectedPerson2 = DBHelper.getInstance().getPersonByIndex(selectedIndexs[1]);
					if(selectedPerson1 == selectedPerson2){
						throw new SelectSamePersonException("You select same person!");
					}
					findOutConnection(selectedPerson1,selectedPerson2);
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
			}
	    	  
	      });
	      relationMenu.add(findOutRelationShipItem);
	      //2. make connection with the two selected persons.
	      makeConnectionItem = new JMenuItem("Make connection");
	      makeConnectionItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {

				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(msTableModel.getSelectedRowCount() < 2){
						throw new SelectLessThanTwoException("Selected person count is less than two! Only two selected persons are allowed.");
					}else if(selectedCount > 2){
						throw new SelectMoreThanTwoException("Selected person count is more than two! Only two selected persons are allowed.");
					}
					int[] selectedIndexs =  msTableModel.getSelectedRowIndexs();
					Person selectedPerson1 = DBHelper.getInstance().getPersonByIndex(selectedIndexs[0]);
					Person selectedPerson2 = DBHelper.getInstance().getPersonByIndex(selectedIndexs[1]);
					if(selectedPerson1 == selectedPerson2){
						throw new SelectSamePersonException("The same person is selected!");
					}
					new SelectRelationshipDialog(MainFrame.this,selectedPerson1,selectedPerson2);
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
			}
	    	  
	      });
	      relationMenu.add(makeConnectionItem);
	      //3. show friend list
	      friendsItem = new JMenuItem("Show Friend List");
	      friendsItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				
				/**
				 * show friend list logic
				 */
				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(selectedCount < 1){
						throw new NoSelectException("No person is selected.");
					}else if(selectedCount > 1){
						throw new SelectMoreThanOneException("Only can show one person's friend list at same time.");
					}
					Person selectedPerson = DBHelper.getInstance().getPersonByIndex(msTableModel.getSelectedRowIndexs()[0]);
					
					if(selectedPerson instanceof YoungChild){
						throw new TooYoungException("This person is too young to have friends.");
					}else if(selectedPerson instanceof Adult){
						
						Adult selcetedAdult = (Adult)selectedPerson;
						String[] namelist = Helper.convertListToArray(selcetedAdult.getFriends());
						new RelationListFrame(selectedPerson.getName()+"'s friend list",namelist,new RelationListFrame.Callback(){
							@Override
							public void onButtonClicked(int select) {
								AdultFriend removedAdult = selcetedAdult.getFriends().get(select);
								DBHelper.getInstance().disConnectFromFriendList(selcetedAdult, removedAdult);
							}
						});
					}else{
						
						Child selcetedChild = (Child)selectedPerson;
						String[] namelist = Helper.convertListToArray(selcetedChild.getFriends());
						new RelationListFrame(selectedPerson.getName()+"'s friend list",namelist,new RelationListFrame.Callback(){
							@Override
							public void onButtonClicked(int select) {
								ChildFriend removedChild = selcetedChild.getFriends().get(select);
								DBHelper.getInstance().disConnectFromFriendList(selcetedChild, removedChild);
							}
						});
						
					}
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
			}
	    	  
	      });
	      relationMenu.add(friendsItem);
	      //4. show colleague list
	      colleaguesItem = new JMenuItem("Show Colleague List");
	      colleaguesItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				
				/**
				 * show colleague list logic
				 */
				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(selectedCount < 1){
						throw new NoSelectException("No person is selected.");
					}else if(selectedCount > 1){
						throw new SelectMoreThanOneException("Only can show one person's colleague list at same time.");
					}
					Person selectedPerson = DBHelper.getInstance().getPersonByIndex(msTableModel.getSelectedRowIndexs()[0]);
					
					if(!(selectedPerson instanceof Adult)){
						throw new TooYoungException("This person is too young to have colleagues,only adult have colleagues.");
					}else{
						
						Adult selcetedAdult = (Adult)selectedPerson;
						String[] namelist = Helper.convertListToArray(selcetedAdult.getColleagues());
						new RelationListFrame(selectedPerson.getName()+"'s colleague list",namelist,new RelationListFrame.Callback(){
							@Override
							public void onButtonClicked(int select) {
								Colleague removedColleague = selcetedAdult.getColleagues().get(select);
								DBHelper.getInstance().disConnectFromColleagueList(selcetedAdult, removedColleague);
							}
						});
					}
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
			}
	    	  
	      });
	      relationMenu.add(colleaguesItem);
	      
	      //4. show classmate list
	      classmatesItem = new JMenuItem("Show Classmate List");
	      classmatesItem.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {

				/**
				 * show classmate list logic
				 */
				try{
					int selectedCount = msTableModel.getSelectedRowCount();
					if(selectedCount < 1){
						throw new NoSelectException("No person is selected.");
					}else if(selectedCount > 1){
						throw new SelectMoreThanOneException("Only can show one person's classmate list at same time.");
					}
					Person selectedPerson = DBHelper.getInstance().getPersonByIndex(msTableModel.getSelectedRowIndexs()[0]);
					
					if(selectedPerson instanceof YoungChild){
						throw new TooYoungException("This person is too young to have classmates.");
					}else if(selectedPerson instanceof Adult){
						
						Adult selcetedAdult = (Adult)selectedPerson;
						String[] namelist = Helper.convertListToArray(selcetedAdult.getClassmates());
						new RelationListFrame(selectedPerson.getName()+"'s classmate list",namelist,new RelationListFrame.Callback(){
							@Override
							public void onButtonClicked(int select) {
								AdultClassmate removedAdult = selcetedAdult.getClassmates().get(select);
								DBHelper.getInstance().disConnectFromClassmateList(selcetedAdult, removedAdult);
							}
						});
					}else{
						
						Child selcetedChild = (Child)selectedPerson;
						String[] namelist = Helper.convertListToArray(selcetedChild.getClassmates());
						new RelationListFrame(selectedPerson.getName()+"'s classmate list",namelist,new RelationListFrame.Callback(){
							@Override
							public void onButtonClicked(int select) {
								ChildClassmate removedChild = selcetedChild.getClassmates().get(select);
								DBHelper.getInstance().disConnectFromClassmateList(selcetedChild, removedChild);
							}
						});
						
					}
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
				
			}
	    	  
	      });
	      relationMenu.add(classmatesItem);
	     
	      menuBar = new JMenuBar();// menu bar
	      menuBar.add(infoMenu);
	      menuBar.add(relationMenu);
	      setJMenuBar(menuBar);
    }
    
    protected void initFrame(){
    	
    	this.setSize(800,500);
        table = new JTable(msTableModel = new MultipleSelectedTableModel(this));  
        
        JScrollPane scroll = new JScrollPane(table); 
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(scroll);  
        super.initFrame();
 
    }
  
    private class MultipleSelectedTableModel extends AbstractTableModel
    { 
        /* 
         * initialize the column names
         */  
        String[] columnNames =  Helper.INFOS;  
        
        Object[][] data = null;  
        private MainFrame mf;
        /** 
         * constructor
         */  
        public MultipleSelectedTableModel(MainFrame mf)  
        {  
        	this.mf = mf;
        	data = DBHelper.getInstance().getAllPersonInformationArray();
//        	mf.selectedStates = new boolean[data.length];
        } 
        
        public void update(){
        	data = DBHelper.getInstance().getAllPersonInformationArray();
//        	mf.selectedStates = new boolean[data.length];
        	this.fireTableDataChanged();
        	
        }
        
        public int getSelectedRowCount(){
        	
        	int selectCount = 0;
        	for(int i = 0 ; i < data.length ; i ++){
        		boolean selectState = (Boolean)data[i][Helper.INFOS.length-1];
        		if(selectState)selectCount++;
        	}
        	return selectCount;
        }
        
        public int[] getSelectedRowIndexs(){
        	
        	int[] selectedIndexs = new int[getSelectedRowCount()];
        	int curIndex = 0;
        	for(int i = 0 ; i < data.length ; i ++){
        		boolean selectState = (Boolean)data[i][Helper.INFOS.length-1];
        		if(selectState)selectedIndexs[curIndex++] = i;
        	}
        	return selectedIndexs;
        }
  
  
        /** 
         * return column name
         */  
        @Override  
        public String getColumnName(int column)  
        {  
            return columnNames[column];  
        }  
          
        /** 
         * return column count
         */  
        @Override  
        public int getColumnCount()  
        {  
            return columnNames.length;  
        }  
  
        /** 
         * return row count
         */  
        @Override  
        public int getRowCount()  
        {  
            return data.length;  
        }  
  
        /**
         * Get the data object with position rowIndex and columIndex 
         */
        @Override  
        public Object getValueAt(int rowIndex, int columnIndex)  
        {  
            return data[rowIndex][columnIndex];  
        }  
  
        /** 
         * get the data of the 'columnIndex' column
         */  
        @Override  
        public Class<?> getColumnClass(int columnIndex)  
        {  
            return data[0][columnIndex].getClass();  
        }  
  
        /** 
         *  return true if the cell of rowIndex & columnIndex is editable , otherwise return false.
         */  
        @Override  
        public boolean isCellEditable(int rowIndex, int columnIndex)  
        {  
       

            if (columnIndex < Helper.INFOS.length-1)  
                return false;  
            else  
                return true;  
        }  
          
        /** 
         * if the data is editable, reset the value to the orginal value.
         */  
        @Override  
        public void setValueAt(Object aValue, int rowIndex, int columnIndex)  
        {  
        	System.out.println("aValue = " + aValue);
        	System.out.println("rowIndex = " + rowIndex);
        	System.out.println("columnIndex = " + columnIndex);
        	
        	
            data[rowIndex][columnIndex] = aValue;  
            //notify to update
            fireTableCellUpdated(rowIndex, columnIndex); 
//            mf.selectedStates[rowIndex] = !(boolean)data[rowIndex][columnIndex];
//            mf.selectedCount = this.getSelectedRowCount();

        }
  
    }
    
//    public int[] getSelectedIndexs(){
//    	int[] selectedIndexs = new int[this.selectedCount];
//    	for(int i = 0,j=0 ; i < selectedStates.length ; i ++){
//    		if(selectedStates[i]){
//    			selectedIndexs[j++] = i;
//    		}
//    	}
//    	return selectedIndexs;
//    }

	@Override
	public void onChanged() {
		
		// TODO Auto-generated method stub
		this.dispose();
		new MainFrame();
	}
	
	/**
	 * find out the connection between the given two people.
	 * @param person1
	 * @param person2
	 */
	public void findOutConnection(Person person1,Person person2){
		//if the two people are all adult
		if(person1 instanceof Adult && person2 instanceof Adult){
			Adult adult1 = (Adult)person1;
			Adult adult2 = (Adult)person2;
			if(adult1.getPartner() == adult2){
				Helper.showNormalInfoDialog(adult1.getName() + " and " + adult2.getName() + " are couples.");
				return;
			}
			if(adult1.getFriends().contains(adult2)){
				Helper.showNormalInfoDialog(adult1.getName() + " and " + adult2.getName() + " are friends.");
				return;
			}
			if(adult1.getColleagues().contains(adult2)){
				Helper.showNormalInfoDialog(adult1.getName() + " and " + adult2.getName() + " are colleagues.");
				return;
			}
			if(adult1.getClassmates().contains(adult2)){
				Helper.showNormalInfoDialog(adult1.getName() + " and " + adult2.getName() + " are classmates.");
				return;
			}
		}
		//if the two people are all children
		else if(person1 instanceof Child && person2 instanceof Child){
			Child child1 = (Child)person1;
			Child child2 = (Child)person2;
			if(child1.getFriends().contains(child2)){
				Helper.showNormalInfoDialog(child1.getName() + " and " + child2.getName() + " are friends.");
				return;
			}
			if(child1.getClassmates().contains(child2)){
				Helper.showNormalInfoDialog(child1.getName() + " and " + child2.getName() + " are classmates.");
				return;
			}
			
		}
		//if person1 is adult, person2 is child
		else if(person1 instanceof Adult && person2 instanceof Kid){
			Adult parent = (Adult)person1;
			Kid kid = (Kid)person2;
			if(parent.getKids().contains(kid)){
				Helper.showNormalInfoDialog(parent.getName() + " is " + kid.getName() + "'s parent.");
				return;
			}
		}
		//if person2 is adult, person1 is child
		else if(person2 instanceof Adult && person1 instanceof Kid){
			Adult parent = (Adult)person2;
			Kid kid = (Kid)person1;
			if(parent.getKids().contains(kid)){
				Helper.showNormalInfoDialog(parent.getName() + " is " + kid.getName() + "'s parent.");
				return;
			}
		}
		Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() + " have not any connection so far.");
		return;
	}
	
}  