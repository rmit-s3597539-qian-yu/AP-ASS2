package com.apassignment2.socialnetwork.gui;

import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;

import javax.swing.JFrame;

public abstract class SocialNetworkJFrame extends JFrame {
	
    private String title;
	public SocialNetworkJFrame(String title){
		this.title = title;
	}
	
	public String getTitle(){
		return title;
	}
	
	protected abstract void initUI();
	
	protected void initFrame(){
		centralize();
		this.setTitle(title);
		this.setResizable(false);
        this.setVisible(true);  
//        this.setDefaultCloseOperation(JFrame.EX);  

	}
	
	public void closeFrame(){
		this.dispose();
	}
	
	protected void centralize(){
		
        GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle screenRec=ge.getDefaultScreenDevice().getDefaultConfiguration().getBounds();
        int centerWidth = ((int)(screenRec.getWidth()-this.getWidth())/2);
        int centerHeight =  ((int)(screenRec.getHeight()-this.getHeight()))/2;
        this.setLocation(centerWidth,centerHeight);
	}

}
