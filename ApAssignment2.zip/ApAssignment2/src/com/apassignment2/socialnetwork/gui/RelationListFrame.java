package com.apassignment2.socialnetwork.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RelationListFrame extends SocialNetworkJFrame {

	private String title;
	private String[] data;
	private Callback callback;

	private JButton removeButton;
	private JButton closeButton;

	private JList list;

	public RelationListFrame(String title, String[] data, Callback callback) {
		super(title);
		this.title = title;
		this.data = data;
		this.callback = callback;
		initUI();
	}

	protected void initUI() {

		// list
		list = new JList(data);
		// buttons
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(2,1));
		removeButton = new JButton("Remove");
		removeButton.setEnabled(false);
		closeButton = new JButton("Close");
		buttonPanel.add(removeButton);
		buttonPanel.add(closeButton);
		//set list select mode as single selection mode
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				//when select item, set removeButton enable
				removeButton.setEnabled(list.getSelectedIndex() >= 0);
			}
		});
		//frame layout
		this.setLayout(new BorderLayout());
		this.add(BorderLayout.CENTER, new JScrollPane(this.list));
		this.add(BorderLayout.SOUTH, buttonPanel);
		this.setSize(400, 300);
		
		// add action for remove Button and close Button
		removeButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				callback.onButtonClicked(list.getSelectedIndex());
				dispose();
			}

		});
		closeButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				dispose();
			}

		});

		super.initFrame();
	}

	public interface Callback {

		public void onButtonClicked(int select);
	}

}
