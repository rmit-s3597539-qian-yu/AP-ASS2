package com.apassignment2.socialnetwork.gui;

import java.awt.BorderLayout;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.apassignment2.socialnetwork.model.Person;

public class SelectPhotoDialog extends  JDialog {
    /******************************* components Definition **************************/
   
    
    private JButton btAdd=new JButton("Select");
    private JButton btExit=new JButton("Close");
    private JButton photo;
    private Person person;
    private DisplayProfileFrame frame;
    public SelectPhotoDialog(DisplayProfileFrame frm,JButton photo) {
        /*********************** UI initialization ***************************/
        super(frm,true);
        frame = frm;
        this.person = person;
        this.photo = photo;
        JPanel panel = new JPanel();
        this.setLayout(new BorderLayout());
        this.add(BorderLayout.CENTER, panel);
        panel.setLayout(new GridLayout(6,6));
        for(int i = 0 ; i < 36 ; i++){
        	final String photoPath = "images/photo_"+(i+1)+".png";
        	JButton btn = new JButton(new ImageIcon(photoPath));
        	btn.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) {
					
					photo.setIcon(btn.getIcon());
					frame.selectedPhtoPath = photoPath;
					dispose();
				}
        		
        	});
        	panel.add(btn);
        }
 
        this.pack();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        /******************* add action listener *******************************/
        centralize();
        this.setResizable(false);
        this.setVisible(true);
    }
    
	protected void centralize(){
		
        GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle screenRec=ge.getDefaultScreenDevice().getDefaultConfiguration().getBounds();
        int centerWidth = ((int)(screenRec.getWidth()-this.getWidth())/2);
        int centerHeight =  ((int)(screenRec.getHeight()-this.getHeight()))/2;
        this.setLocation(centerWidth,centerHeight);
	}
   
}
