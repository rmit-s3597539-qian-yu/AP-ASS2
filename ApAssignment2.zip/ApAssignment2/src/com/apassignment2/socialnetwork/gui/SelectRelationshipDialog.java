package com.apassignment2.socialnetwork.gui;

import java.awt.BorderLayout;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.apassignment2.socialnetwork.Helper;
import com.apassignment2.socialnetwork.database.DBHelper;
import com.apassignment2.socialnetwork.exceptions.AlreadyFriendsException;
import com.apassignment2.socialnetwork.exceptions.AlreadyParentException;
import com.apassignment2.socialnetwork.exceptions.NoAvailableException;
import com.apassignment2.socialnetwork.exceptions.NoSuchRelationException;
import com.apassignment2.socialnetwork.exceptions.NotToBeCoupledException;
import com.apassignment2.socialnetwork.exceptions.SocialNetworkException;
import com.apassignment2.socialnetwork.exceptions.TooYoungException;
import com.apassignment2.socialnetwork.model.Adult;
import com.apassignment2.socialnetwork.model.Child;
import com.apassignment2.socialnetwork.model.Kid;
import com.apassignment2.socialnetwork.model.Person;
import com.apassignment2.socialnetwork.model.YoungChild;
import com.apassignment2.socialnetwork.model.interfaces.Partner;

public class SelectRelationshipDialog extends  JDialog {
   
    
    private JButton makeConnectionButton;
    private JComboBox relationComboBox;
    private Person person1;
    private Person person2;
    
    public SelectRelationshipDialog(JFrame frm, Person person1,Person person2) {

        super(frm,true);
        this.person1 = person1;
        this.person2 = person2;
        JLabel lb = new JLabel("Please choose a relationship for " + person1.getName() + " and " + person2.getName());
        makeConnectionButton=new JButton("Make connection");
        relationComboBox = Helper.createJcomboBox(Helper.CONNECTIONS);
        this.setLayout(new BorderLayout());
        this.add(BorderLayout.NORTH, lb);
        this.add(BorderLayout.CENTER, relationComboBox);
        this.add(BorderLayout.SOUTH, makeConnectionButton);
 
        makeConnectionButton.addActionListener(new ActionListener(){
        	
			@Override
			public void actionPerformed(ActionEvent e) {
				
				boolean result = makeConnection(relationComboBox.getSelectedItem().toString());
				if(result){
					DBHelper.getInstance().notifyDataChanged();
				}
				SelectRelationshipDialog.this.dispose();
			}
        	
        });
        
        this.pack();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        /******************* add action listener *******************************/
        centralize();
        this.setResizable(false);
        this.setVisible(true);
    }
    
	protected void centralize(){
		
        GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle screenRec=ge.getDefaultScreenDevice().getDefaultConfiguration().getBounds();
        int centerWidth = ((int)(screenRec.getWidth()-this.getWidth())/2);
        int centerHeight =  ((int)(screenRec.getHeight()-this.getHeight()))/2;
        this.setLocation(centerWidth,centerHeight);
	}
	
	/**
	 * make connection as the given relation for the selected two people
	 * @param relation
	 */
	private boolean makeConnection(String relation){
		
		try{
			//make connection as couple
			if(relation.equals("Couple")){
				if(!(person1 instanceof Adult) || !(person2 instanceof Adult)){
					throw new NotToBeCoupledException("At least one member is not an adult.");
				}
				Adult adult1 = (Adult)person1;
				Adult adult2 = (Adult)person2;
				if(adult1.getGender().equals(adult2.getGender())){// if their genders are same
					throw new NoAvailableException("They have same genders");
				}else if(adult1.getPartner()!=null || adult2.getPartner()!=null){//if at least one of them has a partner
					throw new NoAvailableException("At least one of them has a partner");
				}
				adult1.marryWith(adult2);
				adult2.marryWith(adult1);
				Helper.showNormalInfoDialog(adult1.getName() + " and " + adult2.getName() +" make connection as " + relation + "successfully!");
				return true;
				
				//make connection as friend
			}else if(relation.equals("Friend")){
				
				if(person1 instanceof YoungChild || person2 instanceof YoungChild){
					throw new TooYoungException("Young child is too young to have friends.");
				}if(person1 instanceof Adult && person2 instanceof Adult){
					
					Adult adult1 = (Adult)person1;
					Adult adult2 = (Adult)person2;
					if(adult1.getFriends().contains(adult2)){
						throw new AlreadyFriendsException(adult1.getName() + "and " + adult2.getName() + " are friends already!");
					}else{
						adult1.addFriend(adult2);
						adult2.addFriend(adult1);
						Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() +" make connection as " + relation + "successfully!");
						return true;
					}
					
				}else if(person1 instanceof Child && person2 instanceof Child){
					
					Child child1 = (Child)person1;
					Child child2 = (Child)person2;
					if(child1.getFriends().contains(child2)){
						throw new AlreadyFriendsException(child1.getName() + "and " + child2.getName() + " are friends already!");
					}else{
						child1.addFriend(child2);
						child2.addFriend(child1);
						Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() +" make connection as " + relation + "successfully!");
						return true;
					}
				}else{
					throw new NoAvailableException("Only adult can make friends with adult or child makes friends with child.");
				}
				
				//make connection as colleague
			}else if(relation.equals("Colleague")){
				
				if(person1 instanceof Kid || person2 instanceof Kid){
					throw new TooYoungException("Kid is too young to have colleagues.");
				}
				if(person1 instanceof Adult && person2 instanceof Adult){
					
					Adult adult1 = (Adult)person1;
					Adult adult2 = (Adult)person2;
					if(adult1.getColleagues().contains(adult2)){
						throw new AlreadyFriendsException(adult1.getName() + "and " + adult2.getName() + " are colleagues already!");
					}else{
						adult1.addColleague(adult2);
						adult2.addColleague(adult1);
						Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() +" make connection as " + relation + "successfully!");
						return true;
					}
					
				}else{
					throw new NoAvailableException("Only adult can make colleagues with an adult.");
				}
				//make connection as classmate
			}else if(relation.equals("Classmate")){
				
				if(person1 instanceof YoungChild || person2 instanceof YoungChild){
					throw new TooYoungException("Young child is too young to have classmates.");
				}if(person1 instanceof Adult && person2 instanceof Adult){
					
					Adult adult1 = (Adult)person1;
					Adult adult2 = (Adult)person2;
					if(adult1.getClassmates().contains(adult2)){
						throw new AlreadyFriendsException(adult1.getName() + "and " + adult2.getName() + " are classmates already!");
					}else{
						adult1.addClassmate(adult2);
						adult2.addClassmate(adult1);
						Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() +" make connection as " + relation + "successfully!");
						return true;
					}
					
				}else if(person1 instanceof Child && person2 instanceof Child){
					
					Child child1 = (Child)person1;
					Child child2 = (Child)person2;
					if(child1.getClassmates().contains(child2)){
						throw new AlreadyFriendsException(child1.getName() + "and " + child2.getName() + " are classmates already!");
					}else{
						child1.addClassmate(child2);
						child2.addClassmate(child1);
						Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() +" make connection as " + relation + "successfully!");
						return true;
					}
				}else{
					throw new NoAvailableException("Only adult can make classmates with adult or child makes classmates with child.");
				}
				//make connection as parent
			}else if(relation.equals("Parent")){
				Adult parent;
				Kid kid;
				if(person1 instanceof Adult && person2 instanceof Kid){
					
					parent= (Adult)person1;
					kid= (Kid)person2;
					
				}else if(person2 instanceof Adult && person1 instanceof Kid){
					
					parent= (Adult)person2;
					kid= (Kid)person1;
				}else{
					throw new NoAvailableException("Only an adult can become a kid's parent!");
				}
				Partner partner = parent.getPartner();
				if(parent.getPartner() == null){
					throw new NoAvailableException("The adult is single now!");
				}
				if(parent.getKids().contains(kid)){
					throw new AlreadyParentException("They have already make connection as parent.");
				}
				kid.setParent(parent);
				kid.setParent(partner);
				parent.addKid(kid);
				partner.addKid(kid);
				Helper.showNormalInfoDialog(person1.getName() + " and " + person2.getName() +" make connection as " + relation + "successfully!");
				
				return true;
			}else{
				throw new NoSuchRelationException("No such relationship.");
			}
			
		}catch(SocialNetworkException exception){
			Helper.showErrorInfoDialog(exception.getErrorInfo());
			return false;
		}
		
		
		
	}
   
}
