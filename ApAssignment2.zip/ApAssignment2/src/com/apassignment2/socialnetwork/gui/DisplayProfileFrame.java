package com.apassignment2.socialnetwork.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.apassignment2.socialnetwork.model.Person;

public class DisplayProfileFrame extends SocialNetworkJFrame{

    private JTextField nameTextField = null;
    private JTextField ageTextField = null;
    private JComboBox genderComboBox = null;
    private JComboBox stateComboBox = null;
    private JTextField statusTextField = null;    
    private JButton saveButton = null;
    private JButton closeButton = null;
    private Person person;
    protected String selectedPhtoPath = null;
	
    public DisplayProfileFrame(Person person){
    	super("Display Profile Frame");
    	this.person = person;
    	this.initUI();
    }
    
    
	@Override
	protected void initUI() {
		
		
		this.setLayout(new BorderLayout());
		this.add(BorderLayout.NORTH,new JLabel("Photo:"));

		JButton photo = new JButton(new ImageIcon(person.getPhotoPath()));
		photo.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				new SelectPhotoDialog(DisplayProfileFrame.this,photo);
				
			}
			
		});
		this.add(BorderLayout.CENTER,photo);
		JPanel southPanel = new JPanel(new GridLayout(1,2));
		saveButton = new JButton("Save");
		closeButton = new JButton("Close");
		southPanel.add(saveButton);
		southPanel.add(closeButton);
		this.add(BorderLayout.SOUTH,southPanel);
		this.pack();
	    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    /******************* add action listener *******************************/
	    saveButton.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				ImageIcon imageIcon = (ImageIcon)photo.getIcon();
				if(selectedPhtoPath!= null){
					person.setPhotoPath(selectedPhtoPath);
				}
				
				closeFrame();
			}
	    	
	    });
	    closeButton.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				
				closeFrame();
			}
	    	
	    });
	    super.initFrame();

	}
	
	

private JTextField createAgeJTextField(){
	
	JTextField ageJTextField = new JTextField();
	
	ageJTextField.addKeyListener(new KeyListener() {  
        @Override  
        public void keyTyped(KeyEvent e) {  
            int temp = e.getKeyChar();  
            System.out.println(temp);  
            if(temp == 10){//check enter key  
              
            }else if(temp != 46){   //check decimal point 
                if(temp != 8){  //check the key 'backspace'
                    //check the number range from 0 ~ 9 
                    if(temp > 57){  
                        e.consume();    
                    }else if(temp < 48){  
                        e.consume();  
                    }  
                }  
            }         
        }  
        @Override  
        public void keyReleased(KeyEvent e) {  
            // TODO Auto-generated method stub  
        }  
        @Override  
        public void keyPressed(KeyEvent e) {  
            // TODO Auto-generated method stub        
        }  
	});  
	
	return ageJTextField;
}

private JComboBox createGenderJcomboBox(String[] data){
	
	JComboBox comboBox = new JComboBox();
	for(int i = 0 ; i < data.length ; i ++){
		comboBox.addItem(data[i]);
	}
	
	return comboBox;
}

private JTextField createJTextField(){
	
	JTextField textField = new JTextField();
	return textField;
} 

}
