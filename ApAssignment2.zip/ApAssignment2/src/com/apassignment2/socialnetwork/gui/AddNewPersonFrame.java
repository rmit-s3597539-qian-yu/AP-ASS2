package com.apassignment2.socialnetwork.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.apassignment2.socialnetwork.Helper;
import com.apassignment2.socialnetwork.database.DBHelper;
import com.apassignment2.socialnetwork.exceptions.EmptyInputException;
import com.apassignment2.socialnetwork.exceptions.SocialNetworkException;

public class AddNewPersonFrame extends SocialNetworkJFrame{

    private JTextField nameTextField;
    private JTextField ageTextField;
    private JComboBox genderComboBox;
    private JComboBox stateComboBox;
    private JTextField statusTextField;
    

    
    private JButton addButton;
    private JButton closeButton;
	
    public AddNewPersonFrame(){
    	super("Add new Person frame");
    	initUI();
    }
    
    
	@Override
	protected void initUI() {
	
		int i = 0;
		
		
		JPanel panel = new JPanel();
		this.setLayout(new BorderLayout());
		this.add(BorderLayout.NORTH,new JLabel(this.getTitle()));
		this.add(panel);
		panel.setLayout(new GridLayout(6,2));
		panel.add(Helper.NEW_PERSON_LABELS[i++]);
		panel.add(nameTextField = createJTextField());
		panel.add(Helper.NEW_PERSON_LABELS[i++]);
		panel.add(ageTextField = createAgeJTextField());
		panel.add(Helper.NEW_PERSON_LABELS[i++]);
		panel.add(genderComboBox = Helper.createJcomboBox(Helper.GENDERS));
		panel.add(Helper.NEW_PERSON_LABELS[i++]);
		panel.add(stateComboBox = Helper.createJcomboBox(Helper.STATES));
		panel.add(Helper.NEW_PERSON_LABELS[i++]);
		panel.add(statusTextField = createJTextField());

		panel.add(addButton = new JButton("Add"));
		panel.add(closeButton = new JButton("Close"));
		this.setSize(300,250);
	    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    /******************* add action listener *******************************/
	    addButton.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				
				try{
					String name = nameTextField.getText();
					if(name == null || name.length() == 0){
						throw new EmptyInputException("Name can not be empty.");
					}
					
					String ageStr = ageTextField.getText();
					if(ageStr == null || ageStr.length() == 0){
						throw new EmptyInputException("Age can not be empty.");
					}
					int age = Integer.parseInt(ageStr);
					
					String gender = genderComboBox.getSelectedItem().toString();
					if(gender == null || gender.length() == 0){
						throw new EmptyInputException("gender can not be empty.");
					}
					
					String state = stateComboBox.getSelectedItem().toString();
					if(state == null || state.length() == 0){
						throw new EmptyInputException("State can not be empty.");
					}
					
					String status = statusTextField.getText();
					if(status == null || status.length() == 0){
						throw new EmptyInputException("status can not be empty.");
					}
					
					DBHelper.getInstance().addNewPerson(name, status, gender, age, state);
					
				}catch(SocialNetworkException exception){
					Helper.showErrorInfoDialog(exception.getErrorInfo());
				}
				
				
				
				closeFrame();
			}
	    	
	    });
	    closeButton.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				
				closeFrame();
			}
	    	
	    });
	    super.initFrame();

	}
	
	

private JTextField createAgeJTextField(){
	
	JTextField ageJTextField = new JTextField();
	
	ageJTextField.addKeyListener(new KeyListener() {  
        @Override  
        public void keyTyped(KeyEvent e) {  
            int temp = e.getKeyChar();  
            System.out.println(temp);  
            if(temp == 10){//check enter key  
              
            }else if(temp != 46){   //check decimal point 
                if(temp != 8){  //check the key 'backspace'
                    //check the number range from 0 ~ 9 
                    if(temp > 57){  
                        e.consume();    
                    }else if(temp < 48){  
                        e.consume();  
                    }  
                }  
            }         
        }  
        @Override  
        public void keyReleased(KeyEvent e) {  
            // TODO Auto-generated method stub  
        }  
        @Override  
        public void keyPressed(KeyEvent e) {  
            // TODO Auto-generated method stub        
        }  
	});  
	
	return ageJTextField;
}

private JTextField createJTextField(){
	
	JTextField textField = new JTextField();
	return textField;
} 

}
