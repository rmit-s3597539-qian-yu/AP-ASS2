package com.apassignment2.socialnetwork.model.interfaces;

import java.util.ArrayList;

public interface ChildClassmate extends Classmate{
	
	public boolean addClassmate(ChildClassmate classmate);
	
	public boolean removeClassmate(ChildClassmate classmate);
	
	public ArrayList<ChildClassmate> getClassmates();

}
