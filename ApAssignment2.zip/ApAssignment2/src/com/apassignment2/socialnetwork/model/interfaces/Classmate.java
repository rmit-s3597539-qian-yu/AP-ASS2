package com.apassignment2.socialnetwork.model.interfaces;

public interface Classmate extends IRelationship{

}
