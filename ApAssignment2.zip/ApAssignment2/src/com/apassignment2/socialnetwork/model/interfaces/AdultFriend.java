package com.apassignment2.socialnetwork.model.interfaces;

import java.util.ArrayList;

public interface AdultFriend extends Friend{
	
	public boolean addFriend(AdultFriend friend);
	
	public boolean removeFriend(AdultFriend friend);
	
	public ArrayList<AdultFriend> getFriends();

}
