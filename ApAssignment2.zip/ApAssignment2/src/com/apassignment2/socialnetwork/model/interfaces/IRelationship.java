package com.apassignment2.socialnetwork.model.interfaces;

public interface IRelationship {
	
	public String getName();

}
