package com.apassignment2.socialnetwork.model.interfaces;

import java.util.ArrayList;

public interface ChildFriend extends Friend{
	
	public boolean addFriend(ChildFriend friend);
	
	public boolean removeFriend(ChildFriend friend);
	
	public ArrayList<ChildFriend> getFriends();

}
