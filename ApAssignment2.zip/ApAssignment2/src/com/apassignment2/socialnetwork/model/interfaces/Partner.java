package com.apassignment2.socialnetwork.model.interfaces;

import java.util.ArrayList;

import com.apassignment2.socialnetwork.model.Kid;

public interface Partner extends IRelationship{
	
	public boolean isMarried();
	
	public boolean marryWith(Partner partner);
	
	public Partner getPartner();
	
	public boolean addKid(Kid kid);
	
	public boolean removeKid(Kid kid);
	
	public String getGender();
	
	public ArrayList<Kid> getKids();

}
