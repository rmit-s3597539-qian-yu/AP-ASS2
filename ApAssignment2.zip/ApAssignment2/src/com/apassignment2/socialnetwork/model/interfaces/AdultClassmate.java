package com.apassignment2.socialnetwork.model.interfaces;

import java.util.ArrayList;

public interface AdultClassmate extends Classmate{

	public boolean addClassmate(AdultClassmate classmate);
	
	public boolean removeClassmate(AdultClassmate classmate);
	
	public ArrayList<AdultClassmate> getClassmates();

}
