package com.apassignment2.socialnetwork.model.interfaces;

import java.util.ArrayList;

public interface Colleague extends IRelationship{
	
	public boolean addColleague(Colleague colleague);
	
	public boolean removeColleague(Colleague colleague);
	
	public ArrayList<Colleague> getColleagues();

}
