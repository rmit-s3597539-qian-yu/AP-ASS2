package com.apassignment2.socialnetwork.model;
import java.util.ArrayList;

/**
 * Person class
 * which actually is the user class of the social network.
 *
 */
public abstract class Person {

	public static final String DEFAULT_EMPTY_PHOTO_PATH = "images/empty.png";
	private String name;
	private String photoPath;
	private int age;
	private String gender;
	private String state;
	private String status;
	

	
	public Person(String name,String photoPath,String status,String gender, int age ,String state) {
		this.name = name;
		this.photoPath = photoPath;
		if(this.photoPath == null || this.photoPath.length() == 0){
			this.photoPath = DEFAULT_EMPTY_PHOTO_PATH;
		}
		this.status = status;
		this.gender = gender;
		this.age = age;
		this.state = state;
	}
	
	public Person(String name,String status,String gender, int age ,String state) {
		this(name,DEFAULT_EMPTY_PHOTO_PATH,status,gender,age,state);
	}

	public String getName(){
		return name;
	}
	
	public String getPhotoPath() {
		return photoPath;
	}

	public void setPhotoPath(String photoPath) {
		this.photoPath = photoPath;
	}

	public String getGender(){
		return gender;
	}
	
	public int getAge(){
		return age;
	}
	
	public String getState() {
		return state;
	}

	public void setState(String hobbies) {
		this.state = hobbies;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public String[] toBasicInfoStringArray(){
		String[] basicInfo = new String[5];
		int i = 0;
		basicInfo[i++] = this.getName();
		basicInfo[i++] = ""+this.getAge();
		basicInfo[i++] = this.getGender();
		basicInfo[i++] = this.getState();
		basicInfo[i++] = this.getStatus();
		
		return basicInfo;
	}
	
	public abstract Object[] generateInfoDataArray();
	
	public void removeAllRelationships(){
		
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.getName();
	}
	
	
}
