package com.apassignment2.socialnetwork.model;
/**
 * YoungChild
 * 
 * as a young child ,he has no friends, classmates as well as colleagues. 
 * the lonly connection he can make is to have parent
 * Description:
 * 
 */
public class YoungChild extends Kid { 

	
	public YoungChild(String name, String photoPath, String status, String gender, int age, String state) {
		super(name, photoPath, status, gender, age, state);
	}

	@Override
	public String getType() {
		return "Young Child";
	}
	

}
