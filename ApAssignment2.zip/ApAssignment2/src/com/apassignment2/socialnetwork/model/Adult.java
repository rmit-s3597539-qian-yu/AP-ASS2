package com.apassignment2.socialnetwork.model;
import java.util.ArrayList;

import com.apassignment2.socialnetwork.model.interfaces.AdultClassmate;
import com.apassignment2.socialnetwork.model.interfaces.AdultFriend;
import com.apassignment2.socialnetwork.model.interfaces.Colleague;
import com.apassignment2.socialnetwork.model.interfaces.Partner;

public class Adult extends Person implements Partner,AdultClassmate,Colleague,AdultFriend{

	private Partner partner = null;
	
	private ArrayList<Kid> children = new ArrayList<Kid>();
	private ArrayList<AdultClassmate> classmates = new ArrayList<AdultClassmate>();
	private ArrayList<Colleague> colleagues = new ArrayList<Colleague>();
	private ArrayList<AdultFriend> friends = new ArrayList<AdultFriend>();
	
	public Adult(String name, String photoPath, String status, String gender, int age, String state) {
		super(name, photoPath, status, gender, age, state);
	}

	@Override
	public boolean addColleague(Colleague colleague) {
		// TODO Auto-generated method stub
		colleagues.add(colleague);
		return true;
	}

	@Override
	public boolean removeColleague(Colleague colleague) {
		// TODO Auto-generated method stub
		colleagues.remove(colleague);
		return true;
	}

	@Override
	public ArrayList<Colleague> getColleagues() {
		// TODO Auto-generated method stub
		return colleagues;
	}

	@Override
	public boolean addClassmate(AdultClassmate classmate) {
		classmates.add(classmate);
		return true;
	}

	@Override
	public boolean removeClassmate(AdultClassmate classmate) {
		classmates.remove(classmate);
		return true;
	}

	@Override
	public ArrayList<AdultClassmate> getClassmates() {
		// TODO Auto-generated method stub
		return this.classmates;
	}

	@Override
	public boolean isMarried() {
		// TODO Auto-generated method stub
		return partner != null;
	}

	@Override
	public boolean marryWith(Partner partner) {
		
		this.partner = partner;
		return true;
	}

	@Override
	public Partner getPartner() {
		
		return partner;
	}

	@Override
	public boolean addKid(Kid kid) {
		this.children.add(kid);
		return true;
	}

	@Override
	public boolean removeKid(Kid kid) {
		// TODO Auto-generated method stub
		children.remove(kid);
		return true;
	}

	@Override
	public ArrayList<Kid> getKids() {
		// TODO Auto-generated method stub
		return this.children;
	}

	@Override
	public Object[] generateInfoDataArray() {
	      Object[] infoDataArray =  new Object[10];
	      int i = 0;
	      infoDataArray[i++] = this.getName();
	      infoDataArray[i++] = "Adult";
	      infoDataArray[i++] = this.getAge();
	      infoDataArray[i++] = this.getGender();
	      infoDataArray[i++] = this.getState();
	      infoDataArray[i++] = this.getStatus();
	      infoDataArray[i++] = this.getPartner() == null ? "" : this.getPartner().getName();
	      infoDataArray[i++] = "";
	      infoDataArray[i++] = "";
	      infoDataArray[i++] = false;
		return infoDataArray;
	}

	@Override
	public boolean addFriend(AdultFriend friend) {
		friends.add(friend);
		return true;
	}

	@Override
	public boolean removeFriend(AdultFriend friend) {
		friends.remove(friend);
		return true;
	}

	@Override
	public ArrayList<AdultFriend> getFriends() {
		
		return friends;
	}


}
