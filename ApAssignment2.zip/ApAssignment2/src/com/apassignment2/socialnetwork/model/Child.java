package com.apassignment2.socialnetwork.model;

import java.util.ArrayList;

import com.apassignment2.socialnetwork.model.interfaces.ChildClassmate;
import com.apassignment2.socialnetwork.model.interfaces.ChildFriend;

/**
 * child class
 *
 */
public class Child extends Kid implements ChildFriend,ChildClassmate{


	private ArrayList<ChildClassmate> classmates = new ArrayList<ChildClassmate>();
	private ArrayList<ChildFriend> friends = new ArrayList<ChildFriend>();
	
	public Child(String name, String photoPath, String status, String gender, int age, String state) {
		super(name, photoPath, status, gender, age, state);
	}
	


	@Override
	public boolean addClassmate(ChildClassmate classmate) {
		
		classmates.add(classmate);
		return true;
	}

	@Override
	public boolean removeClassmate(ChildClassmate classmate) {
		
		classmates.remove(classmate);
		return true;
	}

	@Override
	public ArrayList<ChildClassmate> getClassmates() {
		

		return classmates;
	}

	@Override
	public boolean addFriend(ChildFriend friend) {
		
		friends.add(friend);
		return true;
	}

	@Override
	public boolean removeFriend(ChildFriend friend) {
		
		friends.remove(friend);
		return true;
	}

	@Override
	public ArrayList<ChildFriend> getFriends() {
		
		return friends;
	}



	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "Child";
	}


	

}
