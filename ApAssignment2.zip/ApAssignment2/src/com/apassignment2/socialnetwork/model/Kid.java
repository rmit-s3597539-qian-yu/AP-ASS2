package com.apassignment2.socialnetwork.model;

import com.apassignment2.socialnetwork.model.interfaces.Partner;

public abstract class Kid extends Person{
	
	private Partner father;
	private Partner mother;

	public Kid(String name, String photoPath, String status, String gender, int age, String state) {
		super(name, photoPath, status, gender, age, state);
	}

	
	public void setFather(Partner father){
		this.father = father;
	}
	
	public void setMother(Partner mother){
		this.mother = mother;
	}
	
	public void setParent(Partner parent){
		
		if(parent.getGender().toUpperCase().equals("M")){
			this.father = parent;
		}else{
			this.mother = parent;
		}
	}
	
	public abstract String getType();

	public Partner getFather() {
		return father;
	}
	public Partner getMother() {
		return mother;
	}
	
	@Override
	public Object[] generateInfoDataArray() {
	      Object[] infoDataArray =  new Object[10];
	      int i = 0;
	      infoDataArray[i++] = this.getName();
	      infoDataArray[i++] = this.getType();
	      infoDataArray[i++] = this.getAge();
	      infoDataArray[i++] = this.getGender();
	      infoDataArray[i++] = this.getState();
	      infoDataArray[i++] = this.getStatus();
	      infoDataArray[i++] = "";
	      infoDataArray[i++] = this.getFather() == null ? "" : this.getFather().getName();
	      infoDataArray[i++] = this.getMother() == null ? "" : this.getMother().getName();
	      infoDataArray[i++] = false;
		return infoDataArray;
	}
	
}
