package com.apassignment2.socialnetwork;

import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Helper {
	
	public static final String[] GENDERS = new String[]{"M","F"};
	public static final String[] STATES = new String[]{"ACT","NSW","NT","QLD","SA","TAS","VIC","WA"};
	public static final String[] INFOS = new String[]{ "Full Name","Type", "Age", "Gender", "State", "Status", "Partner","Father" , "Mother" , " Select" }; 
	public static final String[] CONNECTIONS = new String[]{"Couple","Friend","Colleague","Classmate","Parent" };
	public static final JLabel[] NEW_PERSON_LABELS = new JLabel[]{
			new JLabel("Name:"),new JLabel("Age:"),new JLabel("Gender:"),new JLabel("State:"),new JLabel("Status:")
	}; 
	
	public static void showErrorInfoDialog(String errorInfo){
		JOptionPane.showMessageDialog(null, errorInfo, "Error!", JOptionPane.ERROR_MESSAGE); 
	}
	
	public static void showNormalInfoDialog(String info){
		JOptionPane.showMessageDialog(null, info, "Info", JOptionPane.INFORMATION_MESSAGE); 
	}
	
	public static JComboBox createJcomboBox(String[] data){
		
		JComboBox comboBox = new JComboBox();
		for(int i = 0 ; i < data.length ; i ++){
			comboBox.addItem(data[i]);
		}
		
		return comboBox;
	}

	public static String[] convertListToArray(List list){
		String[] array = new String[list.size()];
		for(int i = 0 ; i < list.size() ; i ++){
			array[i] = list.get(i).toString();
		}
		return array;
	}
	
	
}

