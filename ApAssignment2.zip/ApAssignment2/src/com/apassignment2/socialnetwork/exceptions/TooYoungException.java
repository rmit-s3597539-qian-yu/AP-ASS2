package com.apassignment2.socialnetwork.exceptions;

public class TooYoungException extends SocialNetworkException{

	public TooYoungException(String errorInfo) {
		super(errorInfo);
	}

}
