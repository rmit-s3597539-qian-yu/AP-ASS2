package com.apassignment2.socialnetwork.exceptions;

public class AlreadyClassmatesException extends SocialNetworkException{

	public AlreadyClassmatesException(String errorInfo) {
		super(errorInfo);
	}

}
 