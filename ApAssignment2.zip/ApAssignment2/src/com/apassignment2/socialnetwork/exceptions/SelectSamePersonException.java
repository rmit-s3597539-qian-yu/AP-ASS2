package com.apassignment2.socialnetwork.exceptions;

public class SelectSamePersonException extends SocialNetworkException{

	public SelectSamePersonException(String errorInfo) {
		super(errorInfo);
	}

}
