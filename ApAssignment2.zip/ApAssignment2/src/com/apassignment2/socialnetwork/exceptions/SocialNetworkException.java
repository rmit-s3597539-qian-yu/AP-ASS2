package com.apassignment2.socialnetwork.exceptions;

public class SocialNetworkException extends Exception {
	
	private String errorInfo = null;
	public SocialNetworkException(String errorInfo){
		this.errorInfo = errorInfo;
	}
	
	public String getErrorInfo(){
		return errorInfo;
	}

}
