package com.apassignment2.socialnetwork.exceptions;

public class SelectMoreThanOneException extends SocialNetworkException{

	public SelectMoreThanOneException(String errorInfo) {
		super(errorInfo);
	}

}
