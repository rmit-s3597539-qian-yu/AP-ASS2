package com.apassignment2.socialnetwork.exceptions;

public class SelectMoreThanTwoException extends SocialNetworkException{

	public SelectMoreThanTwoException(String errorInfo) {
		super(errorInfo);
	}

}
