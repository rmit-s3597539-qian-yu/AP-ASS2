package com.apassignment2.socialnetwork.exceptions;

public class NoAvailableException extends SocialNetworkException{

	public NoAvailableException(String errorInfo) {
		super(errorInfo);
	}

}
 