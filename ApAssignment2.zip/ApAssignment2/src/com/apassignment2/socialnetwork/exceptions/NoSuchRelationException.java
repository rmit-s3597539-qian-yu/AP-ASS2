package com.apassignment2.socialnetwork.exceptions;

public class NoSuchRelationException extends SocialNetworkException{

	public NoSuchRelationException(String errorInfo) {
		super(errorInfo);
	}

}
 