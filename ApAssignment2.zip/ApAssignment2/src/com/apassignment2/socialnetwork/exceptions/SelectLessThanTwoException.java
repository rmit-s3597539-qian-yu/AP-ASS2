package com.apassignment2.socialnetwork.exceptions;

public class SelectLessThanTwoException extends SocialNetworkException{

	public SelectLessThanTwoException(String errorInfo) {
		super(errorInfo);
	}

}
