package com.apassignment2.socialnetwork.exceptions;

public class AlreadyFriendsException extends SocialNetworkException{

	public AlreadyFriendsException(String errorInfo) {
		super(errorInfo);
	}

}
 