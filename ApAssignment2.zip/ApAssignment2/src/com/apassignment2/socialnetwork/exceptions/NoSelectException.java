package com.apassignment2.socialnetwork.exceptions;

public class NoSelectException extends SocialNetworkException{

	public NoSelectException(String errorInfo) {
		super(errorInfo);
	}

}
 