package com.apassignment2.socialnetwork.exceptions;

public class NotToBeCoupledException extends SocialNetworkException{

	public NotToBeCoupledException(String errorInfo) {
		super(errorInfo);
	}

}
 