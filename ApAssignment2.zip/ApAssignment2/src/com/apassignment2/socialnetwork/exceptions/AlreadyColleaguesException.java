package com.apassignment2.socialnetwork.exceptions;

public class AlreadyColleaguesException extends SocialNetworkException{

	public AlreadyColleaguesException(String errorInfo) {
		super(errorInfo);
	}

}
 