package com.apassignment2.socialnetwork.exceptions;

public class EmptyInputException extends SocialNetworkException{

	public EmptyInputException(String errorInfo) {
		super(errorInfo);
	}

}
 