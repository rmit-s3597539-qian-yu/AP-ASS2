package com.apassignment2.socialnetwork.exceptions;

public class AlreadyParentException extends SocialNetworkException{

	public AlreadyParentException(String errorInfo) {
		super(errorInfo);
	}

}
 